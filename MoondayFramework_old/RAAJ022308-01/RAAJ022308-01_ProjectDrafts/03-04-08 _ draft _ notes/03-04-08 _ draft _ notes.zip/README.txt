Please look at all of the folders (AcceptedDesigns == Accepted, DeniedDesigns == Denied, Examples are how I want FIGA,B,C....)
Send me all of the Customer/Employee General/Ticket/Splash/Login Views and as directed and I'll go ahead and OKay them then you can start on HTML/CSS and PSD/JPG/PNG delivery.


FIGA Customer General View - See my example
FIGB Customer Ticket View - See my example
FIGC Employee Ticket View - See my example

Customer Login View & Employee Login View - Accepted
Customer Splash View & Employee Splash View - Accepted
Employee General View - Accepted

Thanks for your help!