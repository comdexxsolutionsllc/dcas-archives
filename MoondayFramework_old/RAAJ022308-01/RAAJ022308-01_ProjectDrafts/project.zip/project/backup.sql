-- phpMyAdmin SQL Dump
-- version 2.11.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Feb 14, 2008 at 09:58 AM
-- Server version: 5.0.45
-- PHP Version: 5.2.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `raizwan_vinx18phpshop`
--
CREATE DATABASE `raizwan_vinx18phpshop` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `raizwan_vinx18phpshop`;

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(50) NOT NULL default '',
  `content` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` VALUES(1, 'test', 'testestestestestgfdgdfgsdasdascczxsd\r\nsdfds\r\nfds\r\nfds\r\nfdsfdsf');
INSERT INTO `news` VALUES(2, 'ACCOUNTING CLERK IV', 'Position: ACCOUNTING CLERK IV\r\nVacancy Number: 4603-1000-0001-397\r\nSalary Grade: 59\r\nSalary Range: $24605 - $37659\r\nHiring Range: $25495 - $36530\r\nDepartment: EMPLOYMENT SECURITY COMMISSION\r\nDivision: EMPLOYMENT SECURITY COMMISSION\r\nType of Appointment: Perm Full-Time\r\nLocation: WAKE\r\nPosting Date: 10/16/2007\r\nClosing Date: 10/25/2007\r\nNumber of Positions: 1\r\n\r\n	Description of Work\r\n\r\n**NOTE - VACANCY NUMBER (01397) MUST BE ON APPLICATION TO BE CONSIDERED\r\n\r\nINCUMBENT IS RESPONSIBLE FOR A COMBINATION OF THE FOLLOWING DUTIES\r\nRELATING EITHER TO EMPLOYEE TRAVEL, PURCHASES, PAYROLL, OR PAYMENT OF\r\nVENDORS FOR PURCHASES OR SERVICES PROVIDED OR OTHER RELATED ACTIVITIES.\r\nREVIEWS EXPENSE REPORTS, OR VENDOR INVOICES FOR COMPLIANCE WITH\r\nAPPLICABLE POLICIES AND PROCEDURES; VERIFIES EXPENSE CLAIMS OR INVOICES\r\nAND SUPPORTING DOCUMENTATION. DETERMINES ALLOWABLE EXPENSE\r\nREIMBURSEMENTS, PAYMENT AMOUNTS, DISCOUNTS AND EXPENSE ACCOUNT CODES,\r\nENTERS, DATA IN ACCOUNTING AND FINANCIAL SYSTEMS. CONFERS WITH\r\nEMPLOYEES, TRAVEL AGENCIES, PAYROLL OR VENDORS TO OBTAIN ADDITIONAL\r\nINFORMATION AS NEEDED; INVESTIGATES DISCREPANCIES AND RESOLVES\r\nPROBLEMS. MAINTAIN RECORDS TO TRACK TRAVEL ADVANCES OR REIMBURSEMENT\r\nAND PERFORM ACCOUNTING FUNCTIONS SUCH AS POSTING, AND ACCOUNT\r\nBALANCING. INCUMBENT MAINTAINS EMPLOYEE AND VENDOR ACCOUNTING FILES.\r\n\r\nKnowledge, Skills and Abilities\r\n\r\nINCUMBENT MUST BE ABLE TO COMPREHEND AND COMMUNICATE A VAST ARRAY OF\r\nPOLICIES OR PROCEDURES AS IT APPLIES TO JOB DUTIES. INCUMBENT MUST BE\r\nPROFICIENT WITH MICROSOFT COMPUTER APPLICATIONS AND AUTOMATED\r\nACCOUNTING SYSTEMS. INCUMBENT MUST HAVE A GENERAL KNOWLEDGE OF\r\nESTABLISHED ACCOUNTING PRINCIPLES AND TECHNIQUES PERTAINING TO STANDARD\r\nACCOUNTING TRANSACTIONS. INCUMBENT MUST BE ABLE TO COMMUNICATE\r\nEFFECTIVELY BOTH ORALLY AND IN WRITING AND TO INTERACT EFFECTIVELY WITH\r\nALL LEVELS OF PERSONNEL. INCUMBENT SHOULD HAVE THE ABILITY TO PERFORM\r\nROUTINE MATHEMATICAL COMPUTATION.\r\nPREFERENC:\r\nPREFERENCE WILL BE GIVEN TO APPLICANTS WITH 3-5 YEARS OF WORK\r\nEXPERIENCE IN GENERAL ACCOUNTING, ACCOUNTS PAYABLE OR TRAVEL EXPENSE\r\nREPORTING. DEMONSTRATED ABILITY TO ACCOMPLISH TASKS ACCURATELY AND\r\nEFFICIENTLY, HANDLE MULTIPLE TASKS SIMULTANEOUSLY, MEET REGULARLY\r\nRECURRING DEADLINES AND ACT WITH DISCRETION.\r\n\r\nTraining and Experience Requirements\r\n\r\nGRADUATION FROM HIGH SCHOOL AND DEMONSTRATED POSSESSION OF KNOWLEDGES,\r\nSKILLS, AND ABILITIES GAINED THROUGH AT LEAST TWO YEARS OF OFFICE\r\nASSISTANT/SECRETARIAL EXPERIENCE; OR AN EQUIVALENT COMBINATION OF\r\nTRAINING AND EXPERIENCE.\r\n\r\nHow to Apply:\r\n\r\nA state application (PD-107) or faxed PD-107 must be completed and received in our Human Resource Management Department BY 5:00 P.M. on the closing date. A faxed application must be followed by an application with original signatures. A SEPARATE APPLICATION MUST BE SUBMITTED FOR EACH POSITION FOR WHICH YOU ARE APPLYING, AND IT MUST INCLUDE THE POSITION NUMBER TO BE CONSIDERED FOR POSITION. Resumes will not be accepted in lieu of completing a state application.\r\n\r\nDegrees must be received from appropriately accredited institutions.\r\n\r\nApplications are reviewed for education, work experiences, and competencies. Competencies are job-related knowledge, skills and abilities. Identify relevant competencies and major job duties in the work experience section of the application. For Career Banded positions, salary will be commensurate with the selected candidate''s competencies; as well as budget, equity and market considerations.\r\n\r\nIt is the policy of the State of North Carolina and the Employment Security Commission that all employees provide proof of employment eligibility verification (Immigration and Naturalization) within three (3) working days of employment).\r\n\r\nAll applicants who are selected for a position will be subject to a criminal background check.\r\n\r\nContact Person:	ZANETTA D. KING\r\nContact Agency: 	NC-ESC\r\nContact Address: 	P. O. BOX 25903\r\n 	\r\n 	RALEIGH , NC  27611-0000\r\nContact Phone: 	919-733-3100\r\n 	 \r\nContact Fax: 	919-733-0774');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE `tbl_cart` (
  `ct_id` int(10) unsigned NOT NULL auto_increment,
  `pd_id` int(10) unsigned NOT NULL default '0',
  `ct_qty` mediumint(8) unsigned NOT NULL default '1',
  `ct_session_id` char(32) NOT NULL default '',
  `ct_date` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`ct_id`),
  KEY `pd_id` (`pd_id`),
  KEY `ct_session_id` (`ct_session_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=300 ;

--
-- Dumping data for table `tbl_cart`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE `tbl_category` (
  `cat_id` int(10) unsigned NOT NULL auto_increment,
  `cat_parent_id` int(11) NOT NULL default '0',
  `cat_name` varchar(50) NOT NULL default '',
  `cat_description` varchar(200) NOT NULL default '',
  `cat_image` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`cat_id`),
  KEY `cat_parent_id` (`cat_parent_id`),
  KEY `cat_name` (`cat_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=46 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` VALUES(40, 0, '4) Rail', 'Jobs with regard to Rail.', 'a01e76cbf872c926c79a131a6ec5d64e.jpg');
INSERT INTO `tbl_category` VALUES(41, 0, '1) Office staff', '.', '06b266f22e9bd7cff73334984e4ecd09.jpg');
INSERT INTO `tbl_category` VALUES(42, 0, '2) Telecom & IT Sales', 'Jobs with regard to Telecom & IT Sales.', '34124c30e8ce7fa61accdd985c52e821.jpg');
INSERT INTO `tbl_category` VALUES(43, 0, '3) IT & Technical', 'Jobs with regard to IT & Technical.', '2f42b843ceb4d56deef824f4dd1fcdac.jpg');
INSERT INTO `tbl_category` VALUES(44, 0, '5) Sales & Marketing', 'Jobs with regard to Sales & Marketing.', '5be2799a9b3feaebdeed53606354e92e.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_currency`
--

CREATE TABLE `tbl_currency` (
  `cy_id` int(10) unsigned NOT NULL auto_increment,
  `cy_code` char(3) NOT NULL default '',
  `cy_symbol` varchar(8) NOT NULL default '',
  PRIMARY KEY  (`cy_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_currency`
--

INSERT INTO `tbl_currency` VALUES(1, 'EUR', '&#8364;');
INSERT INTO `tbl_currency` VALUES(2, 'GBP', '&pound;');
INSERT INTO `tbl_currency` VALUES(3, 'JPY', '&yen;');
INSERT INTO `tbl_currency` VALUES(4, 'USD', '$');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE `tbl_order` (
  `od_id` int(10) unsigned NOT NULL auto_increment,
  `od_date` datetime default NULL,
  `od_last_update` datetime NOT NULL default '0000-00-00 00:00:00',
  `od_forename` varchar(100) NOT NULL default 'New',
  `od_surname` varchar(100) NOT NULL default '',
  `od_email` varchar(50) NOT NULL default '',
  `od_work_eligibility` varchar(50) NOT NULL default '',
  `od_attachment` varchar(100) NOT NULL default '',
  `od_message` text NOT NULL,
  `od_job` varchar(100) NOT NULL,
  PRIMARY KEY  (`od_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1140 ;

--
-- Dumping data for table `tbl_order`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_item`
--

CREATE TABLE `tbl_order_item` (
  `od_id` int(10) unsigned NOT NULL default '0',
  `pd_id` int(10) unsigned NOT NULL default '0',
  `od_qty` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`od_id`,`pd_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_order_item`
--

INSERT INTO `tbl_order_item` VALUES(1001, 27, 1);
INSERT INTO `tbl_order_item` VALUES(1002, 29, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE `tbl_product` (
  `pd_id` int(10) unsigned NOT NULL auto_increment,
  `cat_id` int(10) unsigned NOT NULL default '0',
  `pd_title` varchar(100) NOT NULL default '',
  `pd_location` varchar(100) NOT NULL default '',
  `pd_salary` text NOT NULL,
  `pd_details` text NOT NULL,
  `pd_image` varchar(200) default NULL,
  `pd_thumbnail` varchar(200) default NULL,
  `pd_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `pd_last_update` datetime NOT NULL default '0000-00-00 00:00:00',
  `order_id` int(10) NOT NULL,
  `prev_order` int(10) NOT NULL,
  `next_order` int(10) NOT NULL,
  PRIMARY KEY  (`pd_id`),
  KEY `cat_id` (`cat_id`),
  KEY `pd_name` (`pd_title`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42 ;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` VALUES(35, 41, 'test 2', 'test', 'kjllkj', 'kjllkj', '', '', '2008-01-07 21:23:24', '0000-00-00 00:00:00', 0, 0, 0);
INSERT INTO `tbl_product` VALUES(34, 40, 'MTSRI01 - IT Software Sales', '- London', '- Salary 18k OTE 36K (Guaranteed £1K per month commission for - 3 months)', 'Our client is a Software Supplier that provides high-quality cost effective solutions for managing IT networks. They serve a diverse customer base including small, medium and large enterprises. With over 400,000 downloaded licenses the company continues to attract new corporate customers.\r\n\r\nThey are gearing up for an exciting future and we''re looking for ambitious individuals for them to join their sales team. You will be looking for your next challenge having acquired a taste for IT Sales in a telemarketing or telesales role. By nature you will be an energetic and self-motivated individual, whose role will involve working with our prospect and customer databases, building new relationships and closing sales opportunities. Because they believe in team spirit, you will receive plenty of encouragement and assistance in achieving your on-target earnings. It''s as important for you as it is for us that you are successful.\r\n\r\nIf you have excellent communication skills and the initiative to think on your feet, you''re someone we need to talk to.\r\n\r\nIt''s an exciting opportunity for anyone wanting to further their career in IT software sales. In addition to excellent on-target earnings, there are additional sales reward schemes and a great social life', '', '', '2007-12-02 00:25:03', '0000-00-00 00:00:00', 0, 0, 0);
INSERT INTO `tbl_product` VALUES(36, 41, 'mickey', 'hjkhkh', 'jkhkjh', 'jkhkjh', '', '', '2008-01-10 22:50:08', '0000-00-00 00:00:00', 0, 0, 0);
INSERT INTO `tbl_product` VALUES(38, 41, 'Purchase Ledger Supervisor - Accounts Payable - Bought Ledger', 'Newbury', '23K', 'This is a great opportunity to work for one of the UK''s largest and fastest growing telecoms network provider and Winner of awards including the Queen''s Award for Enterprise.\r\n\r\nNot only will you be part of an energetic team with an exciting future you will also benefit from the comprehensive rewards package on top of your competitive salary.\r\n\r\nAs a purchase ledger supervisor you will be responsible for the for the effective operations of all aspects of the accounts payable function.\r\n\r\nResponsibilities Include:\r\n\r\n - To process purchase invoices and employee expenses claims \r\n - To manage supplier credit notes and refunds due. \r\n - To reconcile supplier accounts and insure that purchase invoices are properly authorized and paid to terms. \r\n - To manage the credit aspects of supplier relationships maximizing discount opportunities and ensuring that appropriate credit limits are established. \r\n - Assisting in the production of monthly management accounts. \r\n - To assist with the development of the fixed asset register. \r\n - To produce month-end reports as defined. \r\n - To assist with and respond to ad hoc queries. \r\n\r\nSkills:\r\n\r\n - Some accounting training would be an advantage but not essential. \r\n - At least 2 years experience in a similar role. \r\n - MS Office; Word, Excel. \r\n - If you Worked in a network and/or telecoms industry would be an advantage but not essential. \r\n\r\nPackage:\r\n\r\nUp to 23K depending on experience + life assurance + private healthcare + income protection scheme + stakeholder pension scheme + pension + sharesave and more\r\n\r\nPrima Services Group Ltd. is acting as an employment agency on behalf of our client.', '', '', '2008-01-10 23:38:55', '0000-00-00 00:00:00', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_shop_config`
--

CREATE TABLE `tbl_shop_config` (
  `sc_name` varchar(50) NOT NULL default '',
  `sc_address` varchar(100) NOT NULL default '',
  `sc_phone` varchar(30) NOT NULL default '',
  `sc_email` varchar(30) NOT NULL default '',
  `sc_shipping_cost` decimal(5,2) NOT NULL default '0.00',
  `sc_currency` int(10) unsigned NOT NULL default '1',
  `sc_order_email` enum('y','n') NOT NULL default 'n',
  `sc_orderProduct` varchar(100) NOT NULL,
  `sc_orderCategory` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_shop_config`
--

INSERT INTO `tbl_shop_config` VALUES('Job Listings', 'USA', '1234567', 'rmb@raizwan.co.uk', '5.00', 4, 'y', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(10) unsigned NOT NULL auto_increment,
  `first_name` varchar(100) NOT NULL,
  `sur_name` varchar(100) NOT NULL,
  `email_add` varchar(100) NOT NULL,
  `user_name` varchar(20) NOT NULL default '',
  `user_password` varchar(100) NOT NULL,
  `user_regdate` datetime NOT NULL default '0000-00-00 00:00:00',
  `user_last_login` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` VALUES(1, '', '', '', 'admin', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', '0000-00-00 00:00:00', '2008-02-13 18:18:48');
INSERT INTO `tbl_user` VALUES(3, '', '', '', 'webmaster', '026cf3fc6e903caf', '2005-03-02 17:52:51', '0000-00-00 00:00:00');
