<?php
/*
Line 1 : Make sure this file is included instead of requested directly
Line 2 : Check if step is defined and the value is two
Line 3 : The POST request must come from this page but the value of step is one
*/
if (!defined('WEB_ROOT')
    || !isset($_GET['step']) || (int)$_GET['step'] != 2
	|| $_SERVER['HTTP_REFERER'] != 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'] . '?step=1') {
	exit;
}

$errorMessage = '&nbsp;';

/*
 Make sure all the required field exist is $_POST and the value is not empty
 Note: txtShippingAddress2 and txtPaymentAddress2 are optional
*/
$requiredField = array('forename', 'surname', 'email', 'work_eligibility', 'attachment',  'message');
					   
if (!checkRequiredPost($requiredField)) {
	$errorMessage = 'Input not complete';
}

?>

   
<form action="<?php echo $_SERVER['PHP_SELF']; ?>?step=3" method="post" name="frmCheckout" id="frmCheckout" enctype="multipart/form-data"> <p align="center"> 
	<input type="hidden" name="forename" value="<?php echo $_POST['forename'];?>">
	<input type="hidden" name="surname" value="<?php echo $_POST['surname'];?>">
	<input type="hidden" name="email" value="<?php echo $_POST['email'];?>">
	<input type="hidden" name="work_eligibility" value="<?php echo $_POST['work_eligibility'];?>">
	<input type="hidden" name="attachment" value="<?php echo $_POST['attachment'];?>">
	<input type="hidden" name="message" value="<?php echo $_POST['message'];?>">
        <input name="btnBack" type="button" id="btnBack" value="&lt;&lt; Modify Info" onClick="window.location.href='checkout.php?step=1';" class="box">
        &nbsp;&nbsp; 
	
        <input name="btnConfirm" type="submit" id="btnConfirm" value="Confirm &gt;&gt;" class="box"></p>
</form>
<p>&nbsp;</p>
