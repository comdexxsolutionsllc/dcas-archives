<?php
if (!defined('WEB_ROOT')
    || !isset($_GET['step']) || (int)$_GET['step'] != 1) {
	exit;
}
$job_position = $_GET['job'];
$errorMessage = '&nbsp;';
?>
<script language="JavaScript" type="text/javascript" src="library/checkout.js"></script>

  
   
<p id="errorMessage"><?php echo $errorMessage; ?></p>
<form action="<?php echo $_SERVER['PHP_SELF']; ?>?step=3" method="post" name="frmCheckout" id="frmCheckout" onSubmit="return checkShippingAndPaymentInfo();" enctype="multipart/form-data">
    <table width="550" border="0" align="center" cellpadding="5" cellspacing="1" class="entryTable">
	<tr> 
            <td width="150" class="label">Job Position</td>
            <td class="content"><input name="job_position" type="hidden" id="job_position" value="<?php echo $job_position; ?>"><?php echo $job_position; ?></td>
        </tr>	
	<tr><TD colspan="2">To apply for the position, please complete the following form: </TD></tr>
        <tr class="entryTableHeader"> 
            <td colspan="2">Personal Information</td>
        </tr>
        <tr> 
            <td width="150" class="label">Forename</td>
            <td class="content"><input name="forename" type="text" class="box" id="forname" size="30" maxlength="50"></td>
        </tr>
        <tr> 
            <td width="150" class="label">Surname</td>
            <td class="content"><input name="surname" type="text" class="box" id="Surname" size="30" maxlength="50"></td>
        </tr>
        <tr> 
            <td width="150" class="label">E-mail</td>
            <td class="content"><input name="email" type="text" class="box" id="email" size="50" maxlength="50"></td>
        </tr>
        <tr> 
            <td width="150" class="label">Work Eligibility</td>
            <td class="content"><input name="work_eligibility" value="yes" type="radio">Yes, I can prove I am a UK citizen or currently have a UK work permit.<br><input name="work_eligibility" value="no" type="radio">No, I am not currently in possession of a UK work permit.</td>
        </tr>
         <tr> 
            <td class="label">CV Upload</td>
            <td class="content">(*.doc, *.pdf or *.txt documents 
                no larger than 100k.)<br>
                <input name="file" type="file"></td>
        </tr>
        <tr> 
            <td width="150" class="label">Message</td>
            <td class="content"><textarea name="message"  rows="10" cols="40"></textarea></td>
        </tr>
        <tr> 
            <td width="150" class="label">Receive Copy</td>
            <td class="content"><input type="checkbox" name="notification" value="yes"></td>
        </tr>
             
            </table>
  
    <p align="center"> 
        <input class="box" name="btnStep1" type="submit" id="btnStep1" value="Proceed &gt;&gt;">
    </p>
</form>
