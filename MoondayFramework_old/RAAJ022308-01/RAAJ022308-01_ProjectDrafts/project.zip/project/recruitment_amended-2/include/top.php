<?php
if (!defined('WEB_ROOT')) {
	exit;
}
?>
<p>&nbsp;</p>
<p align="center">[ Recruitment website for raizwan ]</p>
<p>&nbsp;</p>