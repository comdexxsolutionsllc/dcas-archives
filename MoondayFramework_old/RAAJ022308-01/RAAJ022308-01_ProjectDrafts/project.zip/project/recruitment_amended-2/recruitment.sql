-- phpMyAdmin SQL Dump
-- version 2.11.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 12, 2007 at 11:14 PM
-- Server version: 5.0.45
-- PHP Version: 5.2.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `vinx18_php_shop`
--
CREATE DATABASE `vinx18_php_shop` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `vinx18_php_shop`;

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(50) NOT NULL default '',
  `content` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `title`, `content`) VALUES
(1, 'test', 'testestestestestgfdgdfgsdasdascczxsd\r\nsdfds\r\nfds\r\nfds\r\nfdsfdsf'),
(2, 'ACCOUNTING CLERK IV', 'Position: ACCOUNTING CLERK IV\r\nVacancy Number: 4603-1000-0001-397\r\nSalary Grade: 59\r\nSalary Range: $24605 - $37659\r\nHiring Range: $25495 - $36530\r\nDepartment: EMPLOYMENT SECURITY COMMISSION\r\nDivision: EMPLOYMENT SECURITY COMMISSION\r\nType of Appointment: Perm Full-Time\r\nLocation: WAKE\r\nPosting Date: 10/16/2007\r\nClosing Date: 10/25/2007\r\nNumber of Positions: 1\r\n\r\n	Description of Work\r\n\r\n**NOTE - VACANCY NUMBER (01397) MUST BE ON APPLICATION TO BE CONSIDERED\r\n\r\nINCUMBENT IS RESPONSIBLE FOR A COMBINATION OF THE FOLLOWING DUTIES\r\nRELATING EITHER TO EMPLOYEE TRAVEL, PURCHASES, PAYROLL, OR PAYMENT OF\r\nVENDORS FOR PURCHASES OR SERVICES PROVIDED OR OTHER RELATED ACTIVITIES.\r\nREVIEWS EXPENSE REPORTS, OR VENDOR INVOICES FOR COMPLIANCE WITH\r\nAPPLICABLE POLICIES AND PROCEDURES; VERIFIES EXPENSE CLAIMS OR INVOICES\r\nAND SUPPORTING DOCUMENTATION. DETERMINES ALLOWABLE EXPENSE\r\nREIMBURSEMENTS, PAYMENT AMOUNTS, DISCOUNTS AND EXPENSE ACCOUNT CODES,\r\nENTERS, DATA IN ACCOUNTING AND FINANCIAL SYSTEMS. CONFERS WITH\r\nEMPLOYEES, TRAVEL AGENCIES, PAYROLL OR VENDORS TO OBTAIN ADDITIONAL\r\nINFORMATION AS NEEDED; INVESTIGATES DISCREPANCIES AND RESOLVES\r\nPROBLEMS. MAINTAIN RECORDS TO TRACK TRAVEL ADVANCES OR REIMBURSEMENT\r\nAND PERFORM ACCOUNTING FUNCTIONS SUCH AS POSTING, AND ACCOUNT\r\nBALANCING. INCUMBENT MAINTAINS EMPLOYEE AND VENDOR ACCOUNTING FILES.\r\n\r\nKnowledge, Skills and Abilities\r\n\r\nINCUMBENT MUST BE ABLE TO COMPREHEND AND COMMUNICATE A VAST ARRAY OF\r\nPOLICIES OR PROCEDURES AS IT APPLIES TO JOB DUTIES. INCUMBENT MUST BE\r\nPROFICIENT WITH MICROSOFT COMPUTER APPLICATIONS AND AUTOMATED\r\nACCOUNTING SYSTEMS. INCUMBENT MUST HAVE A GENERAL KNOWLEDGE OF\r\nESTABLISHED ACCOUNTING PRINCIPLES AND TECHNIQUES PERTAINING TO STANDARD\r\nACCOUNTING TRANSACTIONS. INCUMBENT MUST BE ABLE TO COMMUNICATE\r\nEFFECTIVELY BOTH ORALLY AND IN WRITING AND TO INTERACT EFFECTIVELY WITH\r\nALL LEVELS OF PERSONNEL. INCUMBENT SHOULD HAVE THE ABILITY TO PERFORM\r\nROUTINE MATHEMATICAL COMPUTATION.\r\nPREFERENC:\r\nPREFERENCE WILL BE GIVEN TO APPLICANTS WITH 3-5 YEARS OF WORK\r\nEXPERIENCE IN GENERAL ACCOUNTING, ACCOUNTS PAYABLE OR TRAVEL EXPENSE\r\nREPORTING. DEMONSTRATED ABILITY TO ACCOMPLISH TASKS ACCURATELY AND\r\nEFFICIENTLY, HANDLE MULTIPLE TASKS SIMULTANEOUSLY, MEET REGULARLY\r\nRECURRING DEADLINES AND ACT WITH DISCRETION.\r\n\r\nTraining and Experience Requirements\r\n\r\nGRADUATION FROM HIGH SCHOOL AND DEMONSTRATED POSSESSION OF KNOWLEDGES,\r\nSKILLS, AND ABILITIES GAINED THROUGH AT LEAST TWO YEARS OF OFFICE\r\nASSISTANT/SECRETARIAL EXPERIENCE; OR AN EQUIVALENT COMBINATION OF\r\nTRAINING AND EXPERIENCE.\r\n\r\nHow to Apply:\r\n\r\nA state application (PD-107) or faxed PD-107 must be completed and received in our Human Resource Management Department BY 5:00 P.M. on the closing date. A faxed application must be followed by an application with original signatures. A SEPARATE APPLICATION MUST BE SUBMITTED FOR EACH POSITION FOR WHICH YOU ARE APPLYING, AND IT MUST INCLUDE THE POSITION NUMBER TO BE CONSIDERED FOR POSITION. Resumes will not be accepted in lieu of completing a state application.\r\n\r\nDegrees must be received from appropriately accredited institutions.\r\n\r\nApplications are reviewed for education, work experiences, and competencies. Competencies are job-related knowledge, skills and abilities. Identify relevant competencies and major job duties in the work experience section of the application. For Career Banded positions, salary will be commensurate with the selected candidate''s competencies; as well as budget, equity and market considerations.\r\n\r\nIt is the policy of the State of North Carolina and the Employment Security Commission that all employees provide proof of employment eligibility verification (Immigration and Naturalization) within three (3) working days of employment).\r\n\r\nAll applicants who are selected for a position will be subject to a criminal background check.\r\n\r\nContact Person:	ZANETTA D. KING\r\nContact Agency: 	NC-ESC\r\nContact Address: 	P. O. BOX 25903\r\n 	\r\n 	RALEIGH , NC  27611-0000\r\nContact Phone: 	919-733-3100\r\n 	 \r\nContact Fax: 	919-733-0774');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cart`
--

CREATE TABLE IF NOT EXISTS `tbl_cart` (
  `ct_id` int(10) unsigned NOT NULL auto_increment,
  `pd_id` int(10) unsigned NOT NULL default '0',
  `ct_qty` mediumint(8) unsigned NOT NULL default '1',
  `ct_session_id` char(32) NOT NULL default '',
  `ct_date` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`ct_id`),
  KEY `pd_id` (`pd_id`),
  KEY `ct_session_id` (`ct_session_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=93 ;

--
-- Dumping data for table `tbl_cart`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_category`
--

CREATE TABLE IF NOT EXISTS `tbl_category` (
  `cat_id` int(10) unsigned NOT NULL auto_increment,
  `cat_parent_id` int(11) NOT NULL default '0',
  `cat_name` varchar(50) NOT NULL default '',
  `cat_description` varchar(200) NOT NULL default '',
  `cat_image` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`cat_id`),
  KEY `cat_parent_id` (`cat_parent_id`),
  KEY `cat_name` (`cat_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=40 ;

--
-- Dumping data for table `tbl_category`
--

INSERT INTO `tbl_category` (`cat_id`, `cat_parent_id`, `cat_name`, `cat_description`, `cat_image`) VALUES
(30, 0, 'College Jobs', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut', 'baf887883a0995e3ccb068433fdb4292.jpg'),
(29, 0, 'Diversity Jobs', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut', '20b452d48528010f2259b51c5643e338.jpg'),
(28, 0, 'Healthcare Jobs', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut', '25ed70d8589d84805efbd7c40cbea820.jpg'),
(31, 0, 'Retail Jobs', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut', '7e63896e2eb3b703773905c96266dfa8.jpg'),
(32, 0, 'Sales Jobs', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut', 'b35a90a268a920c38ecdc1578575e219.jpg'),
(33, 0, 'Technology Jobs', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut', '41052070501ba1519af92a421f391b3e.jpg'),
(34, 30, 'Entry Level Jobs', 'Insider Information from Vault\r\n\r\n#\r\n	Vault College Career Bible\r\n#\r\n	Vault Guide to Top Internships\r\n#\r\n	Read employer surveys for more than 3,500 top employers.', 'b21d3e8f3fa57a19850ab76863a0abdd.jpg'),
(35, 29, 'Diversity Job', 'Insider Information from Vault\r\n\r\n#\r\n	Vault Guide to Conquering Corporate America for Women and Minorities\r\n#\r\n	Vault Guide to Schmoozing\r\n#\r\n	Find out how diverse companies really are. Read employer', '87478aa2bc7810b22a691146a6dfa0e5.jpg'),
(36, 28, 'Certified Nursing Assistants/Aides (CNA) Jobs', 'Insider Information from Vault\r\n\r\n#\r\n	Vault Career Guide to Biotech\r\n#\r\n	Vault Guide to Top Biotech/Pharmaceuticals Employers\r\n#\r\n	Read employer surveys from CIGNA, Johnson & Johnson, Medtronic, Pfize', '20f434603860d9877ee64802171cfa04.jpg'),
(37, 31, 'Analyst Jobs', 'Share ideas with other members of the Retail community.', 'c3154cb5fd279a285a4bae184171ddec.jpg'),
(38, 32, 'Account Management Jobs', 'Insider Information from Vault\r\n\r\n#\r\n	Vault Guide to Schmoozing\r\n#\r\n	Read employer surveys for more than 3,500 top employers.', '575a0bca04ee8e5e3d80678e64a4ea18.jpg'),
(39, 33, 'Computer Networking Jobs', 'Insider Information from Vault\r\n\r\n#\r\n	Vault Guide to Technology Careers\r\n#\r\n	Vault Guide to the Top 25 Tech Consulting Firms\r\n#\r\n	Read employer surveys from Accenture, American Management Systems, Boo', '2276cbdb74b8807216c1f223e3b8cac4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_currency`
--

CREATE TABLE IF NOT EXISTS `tbl_currency` (
  `cy_id` int(10) unsigned NOT NULL auto_increment,
  `cy_code` char(3) NOT NULL default '',
  `cy_symbol` varchar(8) NOT NULL default '',
  PRIMARY KEY  (`cy_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tbl_currency`
--

INSERT INTO `tbl_currency` (`cy_id`, `cy_code`, `cy_symbol`) VALUES
(1, 'EUR', '&#8364;'),
(2, 'GBP', '&pound;'),
(3, 'JPY', '&yen;'),
(4, 'USD', '$');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order`
--

CREATE TABLE IF NOT EXISTS `tbl_order` (
  `od_id` int(10) unsigned NOT NULL auto_increment,
  `od_date` datetime default NULL,
  `od_last_update` datetime NOT NULL default '0000-00-00 00:00:00',
  `od_forename` varchar(100) NOT NULL default 'New',
  `od_surname` varchar(100) NOT NULL default '',
  `od_email` varchar(50) NOT NULL default '',
  `od_work_eligibility` varchar(50) NOT NULL default '',
  `od_attachment` varchar(100) NOT NULL default '',
  `od_message` text NOT NULL,
  PRIMARY KEY  (`od_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1013 ;

--
-- Dumping data for table `tbl_order`
--

INSERT INTO `tbl_order` (`od_id`, `od_date`, `od_last_update`, `od_forename`, `od_surname`, `od_email`, `od_work_eligibility`, `od_attachment`, `od_message`) VALUES
(1011, '2007-11-09 19:23:30', '2007-11-09 19:23:30', 'rwer', 'werwer', 'werrewr', 'yes', 'oo-derivatives.doc', 'wrwerr'),
(1012, '2007-11-12 23:07:36', '2007-11-12 23:07:36', 'testr', 'tesdfds', 'garfred_50@yahoo.com', 'yes', '1_905441590l.jpg', 'sdfdsfsdf');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_order_item`
--

CREATE TABLE IF NOT EXISTS `tbl_order_item` (
  `od_id` int(10) unsigned NOT NULL default '0',
  `pd_id` int(10) unsigned NOT NULL default '0',
  `od_qty` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`od_id`,`pd_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_order_item`
--

INSERT INTO `tbl_order_item` (`od_id`, `pd_id`, `od_qty`) VALUES
(1001, 27, 1),
(1002, 29, 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_product`
--

CREATE TABLE IF NOT EXISTS `tbl_product` (
  `pd_id` int(10) unsigned NOT NULL auto_increment,
  `cat_id` int(10) unsigned NOT NULL default '0',
  `pd_title` varchar(100) NOT NULL default '',
  `pd_location` varchar(100) NOT NULL default '',
  `pd_salary` text NOT NULL,
  `pd_details` text NOT NULL,
  `pd_image` varchar(200) default NULL,
  `pd_thumbnail` varchar(200) default NULL,
  `pd_date` datetime NOT NULL default '0000-00-00 00:00:00',
  `pd_last_update` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`pd_id`),
  KEY `cat_id` (`cat_id`),
  KEY `pd_name` (`pd_title`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=34 ;

--
-- Dumping data for table `tbl_product`
--

INSERT INTO `tbl_product` (`pd_id`, `cat_id`, `pd_title`, `pd_location`, `pd_salary`, `pd_details`, `pd_image`, `pd_thumbnail`, `pd_date`, `pd_last_update`) VALUES
(29, 36, 'Certitifed Medical Assistant AAMA or AMT OR LPN (PEDS)', 'Medical Back Office SupportLPN OR BACK OFFICE MEDICAL ASSISTANT NEEDED for a fast growing pediactr', '45.00', 'gnjmb mn,mn ,.n,mn nbnmbn  bmn  nbmn b bb m,n m,bn hgf    jgj hjgjhg jhgjh gg\r\n\r\n hgg  jk  k k mnbmnb n\r\n\r\nhn gjk ghjkh \r\n\r\njhjkhjhjk  hj jkh mkln,mjjOne point, I have already noticed, can you please put the attached CV on the initial form and not on a separate page?\r\n\r\nhello.', 'd68dc0e4418c440f70b1eab84a287fff.jpg', '745dacb34e4b35a7d766c09f48984405.jpg', '2007-10-21 19:46:37', '0000-00-00 00:00:00'),
(33, 36, 'test title', 'location test', 'salary test', 'job details test', '', '', '2007-11-07 01:27:42', '0000-00-00 00:00:00'),
(31, 34, 'Atlanta Journal Constitution Jobs and Profile', 'Atlanta Headquarters: 	Atlanta, GA Industry: 	Communications', '$ 89.00', 'job Details here', 'c7cc48b11f889979bc0a261d1c7f8012.gif', '8cbbe78431637296ae817045ae05d166.jpg', '2007-10-21 19:51:41', '0000-00-00 00:00:00'),
(32, 37, 'Retail Sales - PT Seasonal: Macy''s Imperial Valley: Macy''s West Inc.', 'Job ID	MW00015804\r\nCompany Name	Macy''s West Inc.\r\nJob Category	Retail\r\nLocation	El Centro, CA\r\nPosit', '67.00', '34', 'a3f01c7a26eaa8ea06a908c9cec73875.gif', 'ebd87b7c754910c8918e4ef9f87dd044.jpg', '2007-10-21 19:53:01', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_shop_config`
--

CREATE TABLE IF NOT EXISTS `tbl_shop_config` (
  `sc_name` varchar(50) NOT NULL default '',
  `sc_address` varchar(100) NOT NULL default '',
  `sc_phone` varchar(30) NOT NULL default '',
  `sc_email` varchar(30) NOT NULL default '',
  `sc_shipping_cost` decimal(5,2) NOT NULL default '0.00',
  `sc_currency` int(10) unsigned NOT NULL default '1',
  `sc_order_email` enum('y','n') NOT NULL default 'n'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_shop_config`
--

INSERT INTO `tbl_shop_config` (`sc_name`, `sc_address`, `sc_phone`, `sc_email`, `sc_shipping_cost`, `sc_currency`, `sc_order_email`) VALUES
('Job Listings', 'USA', '1234567', 'jobs@yahoo.com', 5.00, 4, 'y');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE IF NOT EXISTS `tbl_user` (
  `user_id` int(10) unsigned NOT NULL auto_increment,
  `user_name` varchar(20) NOT NULL default '',
  `user_password` varchar(100) NOT NULL,
  `user_regdate` datetime NOT NULL default '0000-00-00 00:00:00',
  `user_last_login` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`user_id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `user_name`, `user_password`, `user_regdate`, `user_last_login`) VALUES
(1, 'admin', '*4ACFE3202A5FF5CF467898FC58AAB1D615029441', '0000-00-00 00:00:00', '2007-11-12 23:12:45'),
(3, 'webmaster', '026cf3fc6e903caf', '2005-03-02 17:52:51', '0000-00-00 00:00:00');

