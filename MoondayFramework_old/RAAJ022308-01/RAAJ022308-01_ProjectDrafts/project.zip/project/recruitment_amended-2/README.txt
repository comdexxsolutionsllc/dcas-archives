
_____________________________________________________


INSTALLATION INSTRUCTIONS

1.) Unzip recruiment.zip to the root folder under your HTTP directory ( or under your preferred directory)

2.) Create a database and database user on your web server for Plaincart

3.) Use the sql dump in recruitment.sql to generate the tables and example data

4.) Modify the database connection settings in library/config.php.

You can start playing with the cart by login to the administrator page.

The default id and password is 'admin' ( without the quotes )

_____________________________________________________