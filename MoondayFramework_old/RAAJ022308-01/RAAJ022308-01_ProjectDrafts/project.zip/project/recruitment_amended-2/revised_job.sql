ALTER TABLE `tbl_order` ADD `od_job` VARCHAR( 100 ) NOT NULL ;
