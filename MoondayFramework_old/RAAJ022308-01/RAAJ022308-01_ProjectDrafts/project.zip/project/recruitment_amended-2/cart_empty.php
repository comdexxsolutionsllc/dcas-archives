<?php
require_once 'library/config.php';
require_once 'library/cart-functions.php';
?>
<html>
<head><title>Cart is Empty</title>
<body>
<p>&nbsp;</p><table width="550" border="0" align="center" cellpadding="10" cellspacing="0">
 <tr>
  <td><p align="center">Your shopping cart is empty</p>
   <p>If you find you are unable to add anything to your cart, please ensure that 
    your internet browser has cookies enabled and that any other security software 
    is not blocking your shopping session.</p></td>
 </tr>
  
</table>
<table width="550" border="0" align="center" cellpadding="10" cellspacing="0">
 <tr align="center"> 
  <td><a href="index.php" class="box">BACK</a></td>
  </tr>
</table>
</body>
</html>
