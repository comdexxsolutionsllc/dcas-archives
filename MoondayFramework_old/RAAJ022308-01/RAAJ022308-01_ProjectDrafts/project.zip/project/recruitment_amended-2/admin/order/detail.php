<?php
if (!defined('WEB_ROOT')) {
	exit;
}

if (!isset($_GET['oid']) || (int)$_GET['oid'] <= 0) {
	header('Location: index.php');
}

$orderId = (int)$_GET['oid'];

// get order information
$sql = "SELECT od_id,od_date, od_last_update, od_job, od_forename, od_surname, od_email, od_work_eligibility, od_attachment, od_message             
	    FROM tbl_order 
		WHERE od_id = $orderId";

$result = dbQuery($sql);
extract(dbFetchAssoc($result));


?>
<p>&nbsp;</p>
<form action="" method="get" name="frmOrder" id="frmOrder">
    <table width="550" border="0"  align="center" cellpadding="5" cellspacing="1" class="detailTable">
        <tr> 
            <td colspan="2" align="center" id="infoTableHeader">Order Detail</td>
        </tr>
        <tr> 
            <td width="150" class="label">ID</td>
            <td class="content"><?php echo $orderId; ?></td>
        </tr>
        <tr> 
            <td width="150" class="label">Order Date</td>
            <td class="content"><?php echo $od_date; ?></td>
        </tr>
        <tr> 
            <td width="150" class="label">Last Update</td>
            <td class="content"><?php echo $od_last_update; ?></td>
        </tr>
	<tr> 
            <td class="label">Job</td>
            <td class="content"><?php echo $od_job; ?></td>
        </tr>
        <tr> 
            <td class="label">Forename</td>
            <td class="content"><?php echo $od_forename; ?></td>
        </tr>
	<tr> 
            <td class="label">Surname</td>
            <td class="content"><?php echo $od_surname; ?></td>
        </tr>
	<tr> 
            <td class="label">Email</td>
            <td class="content"><?php echo $od_email; ?></td>
        </tr>
	<tr> 
            <td class="label">Work Eligibility</td>
            <td class="content"><?php echo $od_work_eligibility; ?></td>
        </tr>
	<tr> 
            <td class="label">Attachment</td>
            <td class="content"><a href="../../upload/<?php echo $od_attachment?>"><?php echo $od_attachment; ?></a></td>
        </tr>	
	<tr> 
            <td class="label">Message</td>
            <td class="content"><?php echo $od_message; ?></td>
        </tr>
    </table>
</form>
<p>&nbsp;</p>

<p align="center"> 
    <input name="btnBack" type="button" id="btnBack" value="Back" class="box" onClick="window.history.back();">
</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
