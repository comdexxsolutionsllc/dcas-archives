<?php
if (!defined('WEB_ROOT')) {
	exit;
}

if (isset($_GET['status']) && $_GET['status'] != '') {
	$status = $_GET['status'];
	$sql2   = " AND od_status = '$status'";
	$queryString = "&status=$status";
} else {
	$status = '';
	$sql2   = '';
	$queryString = '';
}	

if (isset($_GET['delete'])) {
	$id = $_GET['delete'];
	$sql3 = "DELETE FROM tbl_order
		WHERE od_id = '$id'";
	$result = dbQuery($sql3);

}

// for paging
// how many rows to show per page
$rowsPerPage = 10;

$sql = "SELECT od_id,od_date, od_last_update, od_forename, od_surname, od_email, od_work_eligibility, od_attachment, od_message
	    FROM tbl_order";
$result     = dbQuery(getPagingQuery($sql, $rowsPerPage));
$pagingLink = getPagingLink($sql, $rowsPerPage, $queryString);

?>

<p>&nbsp;</p>
<form action="processOrder.php" method="post"  name="frmOrderList" id="frmOrderList">
 <table width="100%" border="0" cellspacing="0" cellpadding="2" class="text">
 <tr align="center"> 
  <td align="right">View</td>
  <td width="75"><select name="cboOrderStatus" class="box" id="cboOrderStatus" onChange="viewOrder();">
    <option value="" selected>All</option>
    <?php echo $orderOption; ?>
  </select></td>
  </tr>
</table>

 <table width="100%" border="0" align="center" cellpadding="2" cellspacing="1" class="text">
  <tr align="center" id="listTableHeader"> 
   <td width="60">ID</td>
   <td>Name</td>
   <td width="60">Email</td>
   <td width="150">Work Eligibility</td>
   <td width="70">Message</td>
   <td width="70">Delete</td>
  </tr>
  <?php
$parentId = 0;
if (dbNumRows($result) > 0) {
	$i = 0;
	
	while($row = dbFetchAssoc($result)) {
		extract($row);
		
		
		if ($i%2) {
			$class = 'row1';
		} else {
			$class = 'row2';
		}
		
		$i += 1;
?>
  <tr class="<?php echo $class; ?>"> 
   <td width="60"><a href="<?php echo $_SERVER['PHP_SELF']; ?>?view=detail&oid=<?php echo $od_id; ?>"><?php echo $od_id; ?></a></td>
   <td><?php echo "$od_forename $od_surname"; ?></td>
   <td width="60" align="right"><?php echo $od_email; ?></td>
   <td width="150" align="center"><?php echo $od_work_eligibility; ?></td>
   <td width="70" align="center"><?php echo $od_message; ?></td>
   <td width="70" align="center"><a href="index.php?delete=<?php echo $od_id; ?>">DELETE</a></td>
  </tr>
  <?php
	} // end while

?>
  <tr> 
   <td colspan="5" align="center">
   <?php 
   echo $pagingLink;
   ?></td>
  </tr>
<?php
} else {
?>
  <tr> 
   <td colspan="5" align="center">No Job Yet </td>
  </tr>
  <?php
}
?>

 </table>
 <p>&nbsp;</p>
</form>
