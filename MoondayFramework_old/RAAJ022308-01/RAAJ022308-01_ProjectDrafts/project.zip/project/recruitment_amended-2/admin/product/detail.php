<?php
if (!defined('WEB_ROOT')) {
	exit;
}

// make sure a product id exists
if (isset($_GET['productId']) && $_GET['productId'] > 0) {
	$productId = $_GET['productId'];
} else {
	// redirect to index.php if product id is not present
	header('Location: index.php');
}

$sql = "SELECT cat_name, pd_title, pd_location, pd_salary, pd_details, pd_image
        FROM tbl_product pd, tbl_category cat
		WHERE pd.pd_id = $productId AND pd.cat_id = cat.cat_id";
$result = mysql_query($sql) or die('Cannot get product. ' . mysql_error());

$row = mysql_fetch_assoc($result);
extract($row);

if ($pd_image) {
	$pd_image = WEB_ROOT . 'images/product/' . $pd_image;
} else {
	$pd_image = WEB_ROOT . 'images/no-image-large.png';
}


?>
<p>&nbsp;</p>
<form action="processProduct.php?action=addProduct" method="post" enctype="multipart/form-data" name="frmAddProduct" id="frmAddProduct">
 <table width="100%" border="0" align="center" cellpadding="5" cellspacing="1" class="entryTable">
  <tr> 
   <td width="150" class="label">Category</td>
   <td class="content"><?php echo $cat_name; ?></td>
  </tr>
  <tr> 
   <td width="150" class="label">Title</td>
   <td class="content"> <?php echo $pd_title; ?></td>
  </tr>
  <tr> 
   <td width="150" class="label">Location</td>
   <td class="content"><?php echo $pd_location; ?> </td>
  </tr>
  <tr> 
   <td width="150" height="36" class="label">Salary</td>
   <td class="content"><?php echo nl2br($pd_salary); ?> </td>
  </tr>
  <tr> 
   <td width="150" class="label">Job Details</td>
   <td class="content"><?php echo nl2br($pd_details); ?> </td>
  </tr>
  <tr> 
   <td width="150" class="label">Image</td>
   <td class="content"><img src="<?php echo $image; ?>"></td>
  </tr>
 </table>
 <p align="center"> 
  <input name="btnModifyProduct" type="button" id="btnModifyProduct" value="Modify Product" onClick="window.location.href='index.php?view=modify&productId=<?php echo $productId; ?>';" class="box">
  &nbsp;&nbsp;
  <input name="btnBack" type="button" id="btnBack" value=" Back " onClick="window.history.back();" class="box">
 </p>
</form>
