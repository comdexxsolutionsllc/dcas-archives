<?php
require_once 'config.php';

/*********************************************************
*                 CHECKOUT FUNCTIONS 
*********************************************************/
function saveOrder()
{
	
	$requiredField = array('forename', 'surname', 'email', 'job_position' ,'work_eligibility', 'attachment',  'message');
	$cartContent = getCartContent();
	$numItem     = count($cartContent);					   
	checkRequiredPost($requiredField);
	    extract($_POST);

  if  ($_FILES["file"]["size"] < 200000)
  {
   if ($_FILES["file"]["error"] > 0)
   {
     echo "Return Code: " . $_FILES["file"]["error"] . "<br />";
	exit;
   }
   else
   {
     echo "Upload: " . $_FILES["file"]["name"] . "<br />";
     echo "Type: " . $_FILES["file"]["type"] . "<br />";
     echo "Size: " . ($_FILES["file"]["size"] / 1024) . " Kb<br />";
     echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br />";
	$random_value = rand();
	$file_to_upload = $_FILES["file"]["name"];
     if (file_exists("upload/$random_value$file_to_upload"))
     {
       echo  "$random_value$file_to_upload already exists. Please change filename";
	exit;
     }
     else
     {
	
	$file_type = $_FILES["file"]["type"];
       @move_uploaded_file($_FILES["file"]["tmp_name"],"upload/" . $_FILES["file"]["name"]);
       echo "Stored in: " . "upload/" . $_FILES["file"]["name"];
	chmod("upload/$file_to_upload", 775);
	rename("upload/$file_to_upload", "$random_value$file_to_upload");
	
	// save order & get order id
       $attachment = "$random_value$file_to_upload";
       $sql = "INSERT INTO tbl_order(od_date, od_last_update,  od_forename, od_surname, od_email, od_job, od_work_eligibility, 
		od_message, od_attachment)
                VALUES (NOW(), NOW(),'$forename', '$surname', '$email', '$job_position', '$work_eligibility', '$message', '$attachment')";
		$result = dbQuery($sql);
		
	for ($i = 0; $i < $numItem; $i++) {
				$sql = "DELETE FROM tbl_cart
				        WHERE ct_id = {$cartContent[$i]['ct_id']}";
				$result = dbQuery($sql);					
        }
        $receive = $_POST['notification'];
	require_once "email_attachment.php";
        if ($receive == "yes") {
		$subject = "[Notification]";
		$emailConfig   = $_SESSION['email'];
		$message = "Job: $job_position <br> Forename: $forename <br> Surname: $surname <br> Email Address: $email <br> Work Elgibility $work_eligibility <br> Message: $message <br> Attachment: $attachment" ;
		
		$fileatt = "upload/$file_to_upload"; // Path to the file
		$fileatt_type = $file_type; // File Type
		$fileatt_name = $file_to_upload; // Filename that will be used for the file as the attachment

		$email_from = $_SESSION['email']; // Who the email is from
		$email_subject = $subject; // The Subject of the email
		$email_message = $message; // Message that the email has in it

		$email_to = $email; // Who the email is too

		email_attachment($fileatt,$fileatt_type,$fileatt_name,$email_from,$email_subject,$email_message,$email_to);
	}
	// send notification email
	
		$subject = "[New Order] " ;
		$message = "You have a new JOB order. Check the order detail in the website";
		$message .= "<br><br>Job: $job_position <br> Forename: $forename <br> Surname: $surname <br> Email Address: $email <br> Work Elgibility $work_eligibility <br> Message: $message <br> Attachment: $attachment" ;

		$fileatt = "upload/$file_to_upload"; // Path to the file
		$fileatt_type = $file_type; // File Type
		$fileatt_name = $file_to_upload; // Filename that will be used for the file as the attachment

		$email_from = $_SESSION['email']; // Who the email is from
		$email_subject = $subject; // The Subject of the email
		$email_message = $message; // Message that the email has in it

		$email_to = $_SESSION['email'];		
		email_attachment($fileatt,$fileatt_type,$fileatt_name,$email_from,$email_subject,$email_message,$email_to);
	
        header("Location: thankyou.php");
        exit;
      }
    }
     
  } else
  {
     echo "Invalid file size";
  }
  

}

/*
	Get order total amount ( total purchase + shipping cost )
*/
function getOrderAmount($orderId)
{
	$orderAmount = 0;
	
	$sql = "SELECT SUM(pd_price * od_qty)
	        FROM tbl_order_item oi, tbl_product p 
		    WHERE oi.pd_id = p.pd_id and oi.od_id = $orderId
			
			UNION
			
			SELECT od_shipping_cost 
			FROM tbl_order
			WHERE od_id = $orderId";
	$result = dbQuery($sql);

	if (dbNumRows($result) == 2) {
		$row = dbFetchRow($result);
		$totalPurchase = $row[0];
		
		$row = dbFetchRow($result);
		$shippingCost = $row[0];
		
		$orderAmount = $totalPurchase + $shippingCost;
	}	
	
	return $orderAmount;	
}

?>
