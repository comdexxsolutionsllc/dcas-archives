ALTER TABLE `tbl_user` ADD `first_name` VARCHAR( 100 ) NOT NULL AFTER `user_id` ,
ADD `sur_name` VARCHAR( 100 ) NOT NULL AFTER `first_name` ,
ADD `email_add` VARCHAR( 100 ) NOT NULL AFTER `sur_name` ;
